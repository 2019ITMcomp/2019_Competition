# @babel/plugin-syntax-typescript

> Allow parsing of TypeScript syntax

See our website [@babel/plugin-syntax-typescript](https://babeljs.io/docs/en/next/babel-plugin-syntax-typescript.html) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-syntax-typescript
```

or using yarn:

```sh
yarn add @babel/plugin-syntax-typescript --dev
```
