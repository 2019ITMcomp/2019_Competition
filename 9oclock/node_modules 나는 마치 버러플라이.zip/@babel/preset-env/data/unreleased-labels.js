module.exports = {
  safari: "tp",
};
