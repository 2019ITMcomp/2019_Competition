# @babel/plugin-transform-spread

> Compile ES2015 spread to ES5

See our website [@babel/plugin-transform-spread](https://babeljs.io/docs/en/next/babel-plugin-transform-spread.html) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-transform-spread
```

or using yarn:

```sh
yarn add @babel/plugin-transform-spread --dev
```
