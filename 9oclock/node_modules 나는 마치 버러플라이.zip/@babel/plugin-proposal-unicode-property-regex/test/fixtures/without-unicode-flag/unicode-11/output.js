var regex = /(?:\uD807[\uDEE0-\uDEF8])/;
