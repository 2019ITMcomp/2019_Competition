var a = /\p{Unified_Ideograph}./u;
var b = /\p{Unified_Ideograph}./su;
