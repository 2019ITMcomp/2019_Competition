var a = /./u;
var b = /./su;
