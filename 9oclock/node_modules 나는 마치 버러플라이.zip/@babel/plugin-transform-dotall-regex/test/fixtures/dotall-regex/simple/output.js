var a = /./;
var b = /[\s\S]/;
