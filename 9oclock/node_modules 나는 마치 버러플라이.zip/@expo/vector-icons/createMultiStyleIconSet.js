import createMultiStyleIconSet from './build/createMultiStyleIconSet';
export default createMultiStyleIconSet;
