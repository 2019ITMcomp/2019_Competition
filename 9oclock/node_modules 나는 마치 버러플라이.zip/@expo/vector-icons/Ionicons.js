import Ionicons from './build/Ionicons';
export default Ionicons;
