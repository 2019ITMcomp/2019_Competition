import Zocial from './build/Zocial';
export default Zocial;
